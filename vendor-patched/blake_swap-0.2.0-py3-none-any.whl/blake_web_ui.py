#!/usr/bin/env python3
from __future__ import annotations

import argparse, json, os, re, secrets, subprocess, sys, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent.parent
BLAKE = ROOT / "scripts" / "blake"
HEALTH = ROOT / "scripts" / "blake-health"
HOST = "127.0.0.1"
PORT_DEFAULT = 8787
CSRF = secrets.token_urlsafe(32)
RECEIVE_CACHE = {}
WITHDRAW_TOKENS = {}
HEX12 = re.compile(r"^[0-9a-fA-F]{12}$")
CHARSET = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"


def run(args, timeout=60):
    p = subprocess.run(args, cwd=ROOT, env=os.environ.copy(), text=True,
                       capture_output=True, timeout=timeout)
    out = (p.stdout or "") + (("\n" if p.stdout and p.stderr else "") + (p.stderr or ""))
    return {"ok": p.returncode == 0, "returncode": p.returncode, "output": out.strip()}


def parse_market(text):
    rows = []
    for raw in text.splitlines():
        parts = re.split(r"\s{2,}", raw.strip())
        if len(parts) >= 5 and HEX12.fullmatch(parts[0]):
            rows.append({"offer": parts[0].lower(), "maker": parts[1],
                         "giving": parts[2], "wanting": parts[3], "expires": parts[4]})
    return rows


def parse_dashboard(text):
    out = {"active": [], "attention": [], "settled": [], "archived": [], "raw": text}
    section = None
    names = {"ACTIVE": "active", "NEEDS ATTENTION": "attention",
             "SETTLED": "settled", "ARCHIVED": "archived"}
    for raw in text.splitlines():
        line = raw.strip()
        if line in names:
            section = names[line]
            continue
        if section not in out or section == "raw":
            continue
        parts = re.split(r"\s{2,}", line)
        if not parts or not HEX12.fullmatch(parts[0]):
            continue
        item = {"swap": parts[0].lower(), "status": parts[1] if len(parts) > 1 else ""}
        if section == "active":
            item["action"] = parts[2] if len(parts) > 2 else ""
            item["trade"] = parts[3] if len(parts) > 3 else ""
        elif section == "attention":
            item["reason"] = " — ".join(parts[2:]) if len(parts) > 2 else ""
        else:
            item["trade"] = parts[2] if len(parts) > 2 else ""
        out[section].append(item)
    return out


def parse_health(text, ok):
    return {"ok": ok and "FAIL  " not in text,
            "passes": sum(x.startswith("PASS  ") for x in text.splitlines()),
            "warnings": sum(x.startswith("WARN  ") for x in text.splitlines()),
            "failures": sum(x.startswith("FAIL  ") for x in text.splitlines()),
            "raw": text}


def polymod(values):
    chk = 1
    gen = [0x3b6a57b2,0x26508e6d,0x1ea119fa,0x3d4233dd,0x2a1462b3]
    for v in values:
        top = chk >> 25
        chk = ((chk & 0x1ffffff) << 5) ^ v
        for i in range(5):
            if (top >> i) & 1: chk ^= gen[i]
    return chk


def convertbits(data, frombits=8, tobits=5):
    acc = bits = 0; ret = []; maxv = (1 << tobits) - 1
    for v in data:
        acc = (acc << frombits) | v; bits += frombits
        while bits >= tobits:
            bits -= tobits; ret.append((acc >> bits) & maxv)
    if bits: ret.append((acc << (tobits - bits)) & maxv)
    return ret


def bech32(hrp, raw):
    data = convertbits(raw)
    exp = [ord(x) >> 5 for x in hrp] + [0] + [ord(x) & 31 for x in hrp]
    pm = polymod(exp + data + [0]*6) ^ 1
    check = [(pm >> (5*(5-i))) & 31 for i in range(6)]
    return hrp + "1" + "".join(CHARSET[x] for x in data + check)


def identity():
    path = os.environ.get("BLAKE_SWAP_PARTICIPANT_KEY_FILE", "")
    if not path: return {"ok": False, "error": "participant key not configured"}
    try:
        secret = bytes.fromhex(Path(path).expanduser().read_text().strip())
        if len(secret) != 32: raise ValueError("participant key must be 32 bytes")
        from coincurve import PrivateKey
        pub = PrivateKey(secret).public_key.format(compressed=True)[1:]
        return {"ok": True, "npub": bech32("npub", pub), "pubkey": pub.hex(),
                "role": os.environ.get("BLAKE_SWAP_ROLE", ""),
                "wallet": os.environ.get("BLAKE_SWAP_CHAIN_WALLET", ""),
                "state_dir": os.environ.get("BLAKE_SWAP_STATE_DIR", "")}
    except Exception as e:
        return {"ok": False, "error": str(e)}



def summary():
    #
    # The dashboard must remain responsive even when
    # Nostr coordination is slow.
    #
    # Do NOT call `blake next` here.  This endpoint is
    # polled frequently by My Swaps.
    #
    h = run(
        [str(HEALTH)]
        if HEALTH.exists()
        else [str(BLAKE), "status"],
        20,
    )

    d = run(
        [str(BLAKE), "dashboard"],
        35,
    )

    if not d["ok"]:
        d = run(
            [str(BLAKE), "swaps"],
            35,
        )

    return {
        "identity": identity(),
        "health": parse_health(
            h["output"],
            h["ok"],
        ),
        "dashboard": parse_dashboard(
            d["output"]
        ),
        "server_time": int(time.time()),
    }


def coordination_status():
    #
    # Coordination/Nostr work is intentionally separate
    # from the dashboard request because it may be slow.
    #
    n = run(
        [str(BLAKE), "next"],
        90,
    )

    return {
        "ok": n["ok"],
        "raw": n["output"],
        "ready_to_fund": (
            "READY TO FUND" in n["output"]
            or
            "READY TO FUND BLAKE" in n["output"]
        ),
    }



AMOUNT_RE = re.compile(
    r"^(?:0|[1-9][0-9]*)(?:\.[0-9]{1,8})?$"
)

#
# UI-only ephemeral state.
#
# Receive addresses remain wallet-owned; this cache only avoids
# generating a fresh address on every 30-second browser refresh.
#
RECEIVE_CACHE = {}

#
# Withdrawal approval tokens are deliberately short-lived and
# process-local.  Restarting the UI invalidates them.
#
WITHDRAW_TOKENS = {}


def chain_config(chain):
    chain = chain.lower()

    if chain == "bitcoin":
        cli = os.environ.get(
            "BLAKE_SWAP_BTC_CLI",
            "",
        )
        datadir = os.environ.get(
            "BLAKE_SWAP_BTC_DATADIR",
            "",
        )
        symbol = "BTC"

    elif chain == "blake":
        cli = os.environ.get(
            "BLAKE_SWAP_BLAKE_CLI",
            "",
        )
        datadir = os.environ.get(
            "BLAKE_SWAP_BLAKE_DATADIR",
            "",
        )
        symbol = "BLAKE"

    else:
        raise ValueError(
            "unknown chain"
        )

    wallet = os.environ.get(
        "BLAKE_SWAP_CHAIN_WALLET",
        "",
    )

    if not cli or not datadir or not wallet:
        raise RuntimeError(
            f"{symbol} wallet configuration is incomplete"
        )

    return {
        "chain": chain,
        "cli": cli,
        "datadir": datadir,
        "wallet": wallet,
        "symbol": symbol,
    }


def wallet_rpc(
    chain,
    *rpc_args,
    timeout=30,
):
    c = chain_config(
        chain
    )

    result = run(
        [
            c["cli"],
            "-regtest",
            f"-datadir={c['datadir']}",
            f"-rpcwallet={c['wallet']}",
            *map(str, rpc_args),
        ],
        timeout,
    )

    if not result["ok"]:
        raise RuntimeError(
            result["output"]
            or
            f"{c['symbol']} wallet RPC failed"
        )

    return result["output"].strip()


def wallet_snapshot(chain):
    c = chain_config(
        chain
    )

    raw = wallet_rpc(
        chain,
        "getbalances",
    )

    obj = json.loads(
        raw
    )

    mine = (
        obj.get("mine", {})
        if isinstance(obj, dict)
        else {}
    )

    trusted = mine.get(
        "trusted",
        0,
    )

    pending = mine.get(
        "untrusted_pending",
        0,
    )

    immature = mine.get(
        "immature",
        0,
    )

    if chain not in RECEIVE_CACHE:
        RECEIVE_CACHE[chain] = wallet_rpc(
            chain,
            "getnewaddress",
            "blake-swap-ui",
        )

    return {
        "chain": chain,
        "symbol": c["symbol"],
        "wallet": c["wallet"],
        "balance": trusted,
        "pending": pending,
        "immature": immature,
        "receive_address":
            RECEIVE_CACHE[chain],
    }


def wallets_snapshot():
    out = {}

    for chain in (
        "bitcoin",
        "blake",
    ):
        try:
            out[chain] = {
                "ok": True,
                **wallet_snapshot(
                    chain
                ),
            }

        except Exception as e:
            out[chain] = {
                "ok": False,
                "chain": chain,
                "error": str(e),
            }

    return out


def new_receive_address(chain):
    addr = wallet_rpc(
        chain,
        "getnewaddress",
        "blake-swap-ui",
    )

    RECEIVE_CACHE[chain] = addr

    return {
        "chain": chain,
        "address": addr,
    }


def validate_withdraw_request(
    chain,
    address,
    amount,
):
    c = chain_config(
        chain
    )

    address = str(
        address
    ).strip()

    amount = str(
        amount
    ).strip()

    if not address:
        raise ValueError(
            "destination address is required"
        )

    if (
        not AMOUNT_RE.fullmatch(amount)
        or float(amount) <= 0
    ):
        raise ValueError(
            "amount must be a positive value "
            "with at most 8 decimals"
        )

    validated = json.loads(
        wallet_rpc(
            chain,
            "validateaddress",
            address,
        )
    )

    if not validated.get(
        "isvalid"
    ):
        raise ValueError(
            f"destination is not a valid "
            f"{c['symbol']} address for this node"
        )

    balance = float(
        wallet_rpc(
            chain,
            "getbalance",
        )
    )

    if float(amount) > balance:
        raise ValueError(
            f"amount exceeds available "
            f"{c['symbol']} wallet balance"
        )

    token = secrets.token_urlsafe(
        24
    )

    WITHDRAW_TOKENS[token] = {
        "chain": chain,
        "address": address,
        "amount": amount,
        "symbol": c["symbol"],
        "expires":
            time.time() + 120,
    }

    return {
        "token": token,
        "chain": chain,
        "symbol": c["symbol"],
        "address": address,
        "amount": amount,
        "fee_note":
            "Network fee is determined by "
            "the local node/wallet policy "
            "and is additional to this amount.",
    }


def execute_withdraw(token):
    item = WITHDRAW_TOKENS.pop(
        str(token),
        None,
    )

    if (
        not item
        or item["expires"] < time.time()
    ):
        raise ValueError(
            "withdrawal review expired; "
            "review it again"
        )

    txid = wallet_rpc(
        item["chain"],
        "sendtoaddress",
        item["address"],
        item["amount"],
        timeout=90,
    )

    return {
        **item,
        "txid": txid,
    }


HTML = r'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>BLAKE Swap</title>
<style>
:root{--bg:#f5f2ea;--paper:#fffdf8;--ink:#20242a;--muted:#6b727b;--line:#ddd7ca;--accent:#303946;--good:#237a44;--warn:#9a6500;--bad:#b42318}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.45 system-ui,sans-serif}header,main{max-width:1100px;margin:auto;padding:22px}.brand{font-weight:850;letter-spacing:.08em;font-size:20px}.pill{background:var(--paper);border:1px solid var(--line);border-radius:99px;padding:7px 11px;font-weight:800}header{display:flex;justify-content:space-between;align-items:center}nav{display:flex;gap:6px;margin-bottom:16px}nav button{border:0;background:transparent;padding:9px 12px;border-radius:8px;font-weight:750;color:var(--muted);cursor:pointer}nav button.active{background:var(--accent);color:#fff}.panel{display:none}.panel.active{display:block}.grid{display:grid;grid-template-columns:repeat(12,1fr);gap:16px}.card{grid-column:span 12;background:var(--paper);border:1px solid var(--line);border-radius:14px;padding:18px;box-shadow:0 10px 28px #00000010}@media(min-width:800px){.two{grid-column:span 8}.one{grid-column:span 4}.half{grid-column:span 6}}h2{margin:0 0 12px;font-size:18px}.k{font-size:11px;text-transform:uppercase;letter-spacing:.09em;font-weight:850;color:var(--muted)}.muted{color:var(--muted)}.mono{font-family:ui-monospace,monospace;overflow-wrap:anywhere}.row,.offer,.swap{border-top:1px solid var(--line);padding:12px 0}.row:first-child,.offer:first-child,.swap:first-child{border-top:0}.offer{display:grid;grid-template-columns:1.4fr 1fr 1fr auto;gap:12px;align-items:center}@media(max-width:700px){.offer{grid-template-columns:1fr 1fr}}button.primary,button.secondary,button.danger{border:0;border-radius:9px;padding:10px 13px;font-weight:800;cursor:pointer}.primary{background:var(--accent);color:#fff}.secondary{background:#ece7dc}.danger{background:var(--bad);color:#fff}button:disabled{opacity:.5}input,select{width:100%;padding:9px;border:1px solid var(--line);border-radius:8px;background:#fff;font:inherit}label{display:block;font-weight:750;margin:8px 0 4px}.notice{padding:12px;border-radius:9px;background:#efebe2;margin:10px 0}.good{border-left:4px solid var(--good)}.warn{border-left:4px solid var(--warn)}.bad{border-left:4px solid var(--bad)}pre{white-space:pre-wrap;background:#20242a;color:#e9eef3;padding:12px;border-radius:9px;font-size:12px;overflow:auto}.modal{position:fixed;inset:0;background:#0008;display:none;place-items:center;padding:20px}.modal.open{display:grid}.dialog{max-width:500px;width:100%;background:var(--paper);border-radius:14px;padding:22px}.actions{display:flex;justify-content:flex-end;gap:8px;margin-top:14px}
</style></head><body><header><div class="brand">BLAKE SWAP <span class="muted">local</span></div><div id="pill" class="pill">checking…</div></header><main>
<nav><button class="active" data-tab="market">Market</button><button data-tab="swaps">My swaps</button><button data-tab="wallets">Swap balances</button><button data-tab="participant">Participant</button></nav>
<section id="market" class="panel active"><div class="grid"><div class="card two"><div style="display:flex;justify-content:space-between"><div><div class="k">Nostr market</div><h2>Open offers</h2></div><button class="secondary" onclick="market()">Refresh</button></div><div id="offers">Loading…</div></div><div class="card one"><div class="k">Maker</div><h2>Create offer</h2><label>Direction</label><select id="dir"><option value="blake-for-btc">Give BLAKE, want BTC</option><option value="btc-for-blake">Give BTC, want BLAKE</option></select><label>BLAKE</label><input id="blake" type="number" step="0.00000001" placeholder="0.01"><label>Sats</label><input id="sats" type="number" step="1" placeholder="2000"><label>Expires in minutes</label><input id="mins" type="number" value="60"><p class="muted">Publishing does not fund a swap.</p><button class="primary" onclick="offer()">Publish offer</button><div id="offerOut"></div></div></div></section>
<section id="swaps" class="panel"><div class="grid"><div class="card two"><div class="k">Local state</div><h2>My swaps</h2><div id="swapList">Loading…</div></div><div class="card one"><div class="k">Action</div><h2>Settlement</h2><div id="action" class="notice">Checking…</div><button class="secondary" onclick="resume()">Resume safe settlement</button><details><summary>Advanced status</summary><pre id="next"></pre></details></div></div></section>
<section id="wallets" class="panel"><div class="grid"><div class="card half"><div class="k">Working capital</div><h2>Bitcoin swap balance</h2><div id="btcWallet">Loading…</div></div><div class="card half"><div class="k">Working capital</div><h2>BLAKE swap balance</h2><div id="blakeWallet">Loading…</div></div><div class="card"><div class="notice warn"><b>Dedicated swap funds only.</b><br>Keep only the amount you intend to trade here. Withdraw proceeds or leftovers back to a wallet you control when you are done.</div></div></div></section>
<section id="participant" class="panel"><div class="grid"><div class="card half"><div class="k">Swap identity</div><h2>Participant</h2><div class="row"><b>npub</b><div id="npub" class="mono muted"></div></div><div class="row"><b>Development role</b> <span id="role"></span></div><div class="row"><b>Wallet</b> <span id="wallet"></span></div><div class="row"><b>State</b><div id="state" class="mono muted"></div></div><p class="muted">The browser sees only the public identity. The signing key stays in the local backend/state directory.</p></div><div class="card half"><div class="k">Readiness</div><h2>Health</h2><div id="health"></div><details><summary>Full output</summary><pre id="healthRaw"></pre></details></div></div></section>
</main><div id="withdrawModal" class="modal"><div class="dialog"><div class="k">Wallet withdrawal</div><h2>Review withdrawal</h2><div id="withdrawReview" class="notice"></div><p>Type <b>WITHDRAW</b> to broadcast this wallet transaction.</p><input id="confirmWithdraw" oninput="withdrawSync()"><div class="actions"><button class="secondary" onclick="withdrawClose()">Cancel</button><button id="withdrawBtn" class="danger" disabled onclick="withdrawNow()">Withdraw</button></div></div></div><div id="modal" class="modal"><div class="dialog"><div class="k">Explicit funding boundary</div><h2>Fund BLAKE HTLC?</h2><p>This is the initial on-chain BLAKE commitment. It is intentionally never automatic.</p><p>Type <b>FUND</b> to continue.</p><input id="confirmFund" oninput="fundSync()"><div class="actions"><button class="secondary" onclick="fundClose()">Cancel</button><button id="fundBtn" class="danger" disabled onclick="fundNow()">Fund BLAKE</button></div></div></div>
<script>
const csrf='__CSRF__',esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>{document.querySelectorAll('nav button').forEach(x=>x.classList.remove('active'));document.querySelectorAll('.panel').forEach(x=>x.classList.remove('active'));b.classList.add('active');document.getElementById(b.dataset.tab).classList.add('active')});
async function api(p,o={}){o.headers=Object.assign({'Content-Type':'application/json','X-Blake-CSRF':csrf},o.headers||{});let r=await fetch(p,o),d=await r.json();if(!r.ok)throw Error(d.error||d.output||`HTTP ${r.status}`);return d}
async function wallets(){try{let d=await api('/api/wallets');renderWallet('bitcoin',d.bitcoin,btcWallet);renderWallet('blake',d.blake,blakeWallet)}catch(e){btcWallet.innerHTML=blakeWallet.innerHTML=`<div class="notice bad">${esc(e.message)}</div>`}}
function renderWallet(chain,w,box){if(!w?.ok){box.innerHTML=`<div class="notice bad">${esc(w?.error||'wallet unavailable')}</div>`;return}box.innerHTML=`<div class="row"><b>Available</b><strong>${esc(w.balance)} ${esc(w.symbol)}</strong></div>${Number(w.pending)?`<div class="row"><span>Pending</span><span>${esc(w.pending)} ${esc(w.symbol)}</span></div>`:''}<label>Receive address</label><div class="mono" style="padding:10px;background:#f0ece3;border-radius:8px">${esc(w.receive_address)}</div><div style="display:flex;gap:8px;margin-top:8px"><button class="secondary" onclick="copyText('${esc(w.receive_address)}')">Copy</button><button class="secondary" onclick="newReceive('${chain}')">New address</button></div><hr style="border:0;border-top:1px solid var(--line);margin:18px 0"><div class="k">Withdraw</div><label>Destination</label><input id="${chain}Dest" placeholder="Paste ${esc(w.symbol)} address"><label>Amount</label><input id="${chain}Amount" type="number" min="0" step="0.00000001" placeholder="0.001"><p class="muted">Withdrawal is a normal wallet send, separate from swap HTLC funding.</p><button class="secondary" onclick="prepareWithdraw('${chain}')">Review withdrawal</button>`}
async function copyText(t){try{await navigator.clipboard.writeText(t)}catch(e){prompt('Copy address:',t)}}
async function newReceive(chain){try{await api('/api/receive',{method:'POST',body:JSON.stringify({chain})});wallets()}catch(e){alert(e.message)}}
let pendingWithdrawal=null;async function prepareWithdraw(chain){let address=document.getElementById(chain+'Dest').value,amount=document.getElementById(chain+'Amount').value;try{pendingWithdrawal=await api('/api/withdraw/prepare',{method:'POST',body:JSON.stringify({chain,address,amount})});withdrawReview.innerHTML=`<b>${esc(pendingWithdrawal.amount)} ${esc(pendingWithdrawal.symbol)}</b><br>to <span class="mono">${esc(pendingWithdrawal.address)}</span><br><br><span class="muted">${esc(pendingWithdrawal.fee_note)}</span>`;confirmWithdraw.value='';withdrawSync();withdrawModal.classList.add('open')}catch(e){alert(e.message)}}
function withdrawClose(){withdrawModal.classList.remove('open');pendingWithdrawal=null}function withdrawSync(){withdrawBtn.disabled=confirmWithdraw.value!=='WITHDRAW'}async function withdrawNow(){if(!pendingWithdrawal||confirmWithdraw.value!=='WITHDRAW')return;withdrawBtn.disabled=true;try{let d=await api('/api/withdraw',{method:'POST',body:JSON.stringify({token:pendingWithdrawal.token,confirm:'WITHDRAW'})});withdrawClose();alert(`Withdrawal broadcast. Txid: ${d.txid}`);wallets()}catch(e){alert(e.message);withdrawSync()}}
function marketTTL(expiresAt){
    let remaining=Math.max(0,Number(expiresAt)-Math.floor(Date.now()/1000));
    if(remaining<60)return `${remaining}s`;
    if(remaining<3600)return `${Math.floor(remaining/60)}m`;
    if(remaining<86400)return `${Math.floor(remaining/3600)}h`;
    return `${Math.floor(remaining/86400)}d`;
}

function marketTerms(o){
    let blake=`${o.blake_amount} BLAKE`;
    let sats=`${Number(o.btc_sats).toLocaleString()} sats`;

    if(o.direction==='blake-for-btc'){
        return {giving:blake,wanting:sats};
    }

    if(o.direction==='btc-for-blake'){
        return {giving:sats,wanting:blake};
    }

    return {giving:'Unknown terms',wanting:'Unknown terms'};
}

async function market(){
    let x=document.getElementById('offers');

    try{
        let d=await api('/api/market');

        let offers=(d.offers||[]).filter(
            o=>o && o.state==='OPEN'
        );

        if(!offers.length){
            x.innerHTML='<div class="muted">No valid open offers found.</div>';
            return;
        }

        x.innerHTML=offers.map(o=>{
            let id=String(o.event_id||'');
            let prefix=id.slice(0,12);
            let terms=marketTerms(o);

            return `<div class="offer">
                <div>
                    <div class="k">${esc(prefix)}</div>
                    <b>${esc(terms.giving)}</b>
                    <div class="muted">for ${esc(terms.wanting)}</div>
                </div>
                <div>
                    <div class="k">maker</div>
                    <span class="mono">${esc(o.maker)}</span>
                </div>
                <div>
                    <div class="k">expires</div>
                    ${esc(marketTTL(o.expires_at))}
                </div>
                <button class="primary" onclick="take('${esc(prefix)}')">Take</button>
            </div>`;
        }).join('');

    }catch(e){
        x.innerHTML=`<div class="notice bad">${esc(e.message)}</div>`;
    }
}
async function take(id){if(!confirm(`Take ${id}? This publishes a signed take but does not fund BLAKE.`))return;try{let d=await api('/api/take',{method:'POST',body:JSON.stringify({offer:id})});alert(d.output||'Taken');refresh()}catch(e){alert(e.message)}}
async function offer(){let p={direction:dir.value,blake:Number(blake.value),sats:Number(sats.value),minutes:Number(mins.value)};try{let d=await api('/api/offer',{method:'POST',body:JSON.stringify(p)});offerOut.innerHTML=`<div class="notice good">${esc(d.output)}</div>`;market()}catch(e){offerOut.innerHTML=`<div class="notice bad">${esc(e.message)}</div>`}}
function swapWorkflow(x){
    const state=String(x.status||'').toUpperCase();
    const act=String(x.action||'').toLowerCase();

    if(state==='OFFERED'){
        return 'Negotiation complete — awaiting BLAKE funding';
    }

    if(state==='BLAKE_FUNDED'){
        if(act==='fund-btc'){
            return 'BLAKE funded — Bitcoin funding ready';
        }
        if(act==='sync-funding'){
            return 'BLAKE funded — synchronizing Bitcoin funding';
        }
        return 'BLAKE funded — awaiting Bitcoin funding';
    }

    if(state==='BTC_FUNDED'){
        if(act==='claim-btc'){
            return 'Bitcoin funded — Alice can claim BTC';
        }
        if(act==='sync-settlement'){
            return 'Bitcoin funded — detecting Alice claim';
        }
        return 'Bitcoin funded — awaiting Alice claim';
    }

    if(state==='BTC_CLAIMED'){
        if(act==='claim-blake'){
            return 'Bitcoin claimed — Bob can claim BLAKE';
        }
        if(act==='sync-settlement'){
            return 'Bitcoin claimed — detecting BLAKE claim';
        }
        return 'Bitcoin claimed — awaiting BLAKE claim';
    }

    if(state==='BLAKE_CLAIMED'){
        return 'BLAKE claimed — finalizing swap';
    }

    if(state==='COMPLETE'){
        return 'Complete';
    }

    if(state==='BTC_REFUNDED'){
        return 'Bitcoin refunded — awaiting BLAKE recovery';
    }

    if(state==='BLAKE_REFUNDED'){
        return 'Refunded';
    }

    if(state==='REFUNDED'){
        return 'Refunded';
    }

    return x.reason || x.action || x.status || 'Unknown state';
}

function swapRow(x){
    const workflow=swapWorkflow(x);
    const raw=[
        x.status ? `state: ${x.status}` : '',
        x.action ? `next: ${x.action}` : ''
    ].filter(Boolean).join(' · ');

    return `<div class="swap">
        <div style="display:flex;justify-content:space-between;gap:12px">
            <b class="mono">${esc(x.swap)}</b>
            <b>${esc(workflow)}</b>
        </div>
        <div>${esc(x.trade||'')}</div>
        ${raw?`<div class="muted">${esc(raw)}</div>`:''}
        ${x.reason?`<div class="muted">${esc(x.reason)}</div>`:''}
    </div>`;
}
async function summary(){try{let d=await api('/api/summary'),h=d.health;pill.textContent=h.ok?(h.warnings?`READY · ${h.warnings} warning`:'READY'):'NOT READY';pill.style.color=h.ok?(h.warnings?'var(--warn)':'var(--good)'):'var(--bad)';health.innerHTML=`<div class="notice ${h.ok?(h.warnings?'warn':'good'):'bad'}">${h.passes} pass · ${h.warnings} warning · ${h.failures} fail</div>`;healthRaw.textContent=h.raw||'';let i=d.identity||{};npub.textContent=i.npub||i.error||'unavailable';role.textContent=i.role||'—';wallet.textContent=i.wallet||'—';state.textContent=i.state_dir||'—';let a=d.dashboard,html='';['active','attention','settled'].forEach(k=>{if(a[k]?.length)html+=`<div class="k" style="margin-top:12px">${k}</div>`+a[k].map(swapRow).join('')});swapList.innerHTML=html||'<div class="muted">No swaps found.</div>';next.textContent=d.next.raw||'';if(d.next.ready_to_fund){action.className='notice warn';action.innerHTML='<b>ACTION REQUIRED</b><br>Initial BLAKE funding requires your explicit approval.<br><br><button class="danger" onclick="fundOpen()">Review BLAKE funding</button>'}else{action.className='notice good';action.textContent='No explicit BLAKE funding action is currently required.'}}catch(e){pill.textContent='ERROR';pill.style.color='var(--bad)'}}
async function resume(){try{let d=await api('/api/resume',{method:'POST',body:'{}'});alert(d.output||'Resume complete');summary()}catch(e){alert(e.message)}}
function fundOpen(){confirmFund.value='';fundSync();modal.classList.add('open')}function fundClose(){modal.classList.remove('open')}function fundSync(){fundBtn.disabled=confirmFund.value!=='FUND'}async function fundNow(){if(confirmFund.value!=='FUND')return;fundBtn.disabled=true;try{let d=await api('/api/fund',{method:'POST',body:JSON.stringify({confirm:'FUND'})});fundClose();alert(d.output||'Funding submitted');summary()}catch(e){alert(e.message);fundSync()}}
let summaryBusy=false;
let marketBusy=false;
let walletsBusy=false;

async function safeSummary(){
    if(summaryBusy)return;
    summaryBusy=true;
    try{await summary()}
    finally{summaryBusy=false}
}

async function safeMarket(){
    if(marketBusy)return;
    marketBusy=true;
    try{await market()}
    finally{marketBusy=false}
}

async function safeWallets(){
    if(walletsBusy)return;
    walletsBusy=true;
    try{await wallets()}
    finally{walletsBusy=false}
}

function refresh(){
    safeSummary();
    safeMarket();
    safeWallets();
}

refresh();
setInterval(safeSummary,30000);
setInterval(safeMarket,30000);
setInterval(safeWallets,30000);
</script></body></html>'''


class Handler(BaseHTTPRequestHandler):
    server_version = "BlakeSwapLocalUI/1.1"
    def log_message(self, fmt, *args): sys.stderr.write("[ui] " + (fmt % args) + "\n")
    def json(self, obj, status=200):
        body = json.dumps(obj).encode(); self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body))); self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff"); self.end_headers(); self.wfile.write(body)
    def html(self):
        body = HTML.replace("__CSRF__", CSRF).encode(); self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8"); self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store"); self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy", "default-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'")
        self.end_headers(); self.wfile.write(body)
    def read_json(self):
        n = int(self.headers.get("Content-Length", "0"));
        if n > 65536: raise ValueError("request too large")
        return json.loads((self.rfile.read(n) if n else b"{}").decode())
    def do_GET(self):
        p = urlparse(self.path).path
        if p == "/": return self.html()
        if p == "/api/summary":
            try:
                return self.json(
                    summary()
                )
            except Exception as e:
                return self.json(
                    {"error": str(e)},
                    500,
                )

        if p == "/api/next":
            try:
                return self.json(
                    coordination_status()
                )
            except subprocess.TimeoutExpired:
                return self.json(
                    {
                        "error": "coordination check timed out",
                        "slow": True,
                    },
                    504,
                )
            except Exception as e:
                return self.json(
                    {"error": str(e)},
                    500,
                )
        if p == "/api/market":
            try:
                r = run(
                    [
                        str(BLAKE),
                        "engine",
                        "market-state",
                        "--json",
                    ],
                    45,
                )

                if not r["ok"]:
                    return self.json(
                        {
                            "error":
                                r["output"]
                                or "market-state command failed"
                        },
                        502,
                    )

                try:
                    payload = json.loads(
                        r["output"]
                    )
                except json.JSONDecodeError as e:
                    return self.json(
                        {
                            "error":
                                "market-state returned invalid JSON",
                            "detail": str(e),
                        },
                        502,
                    )

                if not isinstance(payload, dict):
                    return self.json(
                        {
                            "error":
                                "market-state returned non-object JSON"
                        },
                        502,
                    )

                offers = payload.get("offers")

                if not isinstance(offers, list):
                    return self.json(
                        {
                            "error":
                                "market-state JSON has invalid offers field"
                        },
                        502,
                    )

                return self.json(
                    {
                        "offers": offers,
                    }
                )

            except Exception as e:
                return self.json(
                    {"error": str(e)},
                    500,
                )
        if p == "/api/wallets":
            try: return self.json(wallets_snapshot())
            except Exception as e: return self.json({"error": str(e)}, 500)
        return self.json({"error": "not found"}, 404)
    def do_POST(self):
        if not secrets.compare_digest(self.headers.get("X-Blake-CSRF", ""), CSRF):
            return self.json({"error": "CSRF validation failed"}, 403)
        try:
            data = self.read_json(); p = urlparse(self.path).path
            if p == "/api/take":
                oid = str(data.get("offer", "")).lower()
                if not HEX12.fullmatch(oid): raise ValueError("invalid offer prefix")
                r = run([str(BLAKE), "take", oid], 60)
            elif p == "/api/offer":
                direction = str(data.get("direction", "")); bl = float(data.get("blake")); sats = int(data.get("sats")); mins = int(data.get("minutes"))
                if direction not in {"blake-for-btc", "btc-for-blake"}: raise ValueError("invalid direction")
                if bl <= 0 or sats <= 0 or mins <= 0: raise ValueError("amounts and expiry must be positive")
                r = run([str(BLAKE), "offer", direction, "--blake", str(bl), "--sats", str(sats), "--minutes", str(mins)], 60)
            elif p == "/api/resume": r = run([str(BLAKE), "resume"], 90)
            elif p == "/api/receive":
                chain = str(data.get("chain", "")).lower()
                return self.json(new_receive_address(chain))
            elif p == "/api/withdraw/prepare":
                chain = str(data.get("chain", "")).lower()
                return self.json(validate_withdraw_request(chain, data.get("address", ""), data.get("amount", "")))
            elif p == "/api/withdraw":
                if data.get("confirm") != "WITHDRAW": return self.json({"error": "explicit WITHDRAW confirmation required"}, 400)
                return self.json(execute_withdraw(data.get("token", "")))
            elif p == "/api/fund":
                if data.get("confirm") != "FUND": return self.json({"error": "explicit FUND confirmation required"}, 400)
                r = run([str(BLAKE), "fund"], 90)
            else: return self.json({"error": "not found"}, 404)
            return self.json({"ok": r["ok"], "output": r["output"], "returncode": r["returncode"]}, 200 if r["ok"] else 502)
        except (ValueError, TypeError) as e: return self.json({"error": str(e)}, 400)
        except subprocess.TimeoutExpired: return self.json({"error": "command timed out"}, 504)
        except Exception as e: return self.json({"error": str(e)}, 500)


def checks():
    errs = []
    if not BLAKE.is_file(): errs.append(f"missing {BLAKE}")
    if not os.environ.get("BLAKE_SWAP_STATE_DIR"): errs.append("BLAKE_SWAP_STATE_DIR is not set; source a participant profile")
    if not os.environ.get("BLAKE_SWAP_PARTICIPANT_KEY_FILE"): errs.append("BLAKE_SWAP_PARTICIPANT_KEY_FILE is not set")
    return errs


def main():
    ap = argparse.ArgumentParser(description="Local-only BLAKE Swap web UI")
    ap.add_argument("--port", type=int, default=int(os.environ.get("BLAKE_SWAP_UI_PORT", PORT_DEFAULT)))
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args(); errs = checks()
    if errs:
        for e in errs: print("FAIL ", e, file=sys.stderr)
        raise SystemExit(2)
    i = identity()
    if not i.get("ok"): raise SystemExit("FAIL  participant identity: " + i.get("error", "unknown"))
    if a.check:
        print("PASS  local web UI prerequisites")
        print("PASS  participant identity:", i["npub"])
        print("PASS  bind policy:", HOST)
        print("PASS  initial BLAKE funding requires typed FUND confirmation")
        print("PASS  wallet withdrawals require review + typed WITHDRAW confirmation")
        return
    if not (1 <= a.port <= 65535): raise SystemExit("invalid port")
    s = ThreadingHTTPServer((HOST, a.port), Handler)
    print("\nBLAKE SWAP LOCAL UI\n===================")
    print(f"Open: http://{HOST}:{a.port}\nBinding: localhost only\nCtrl-C stops the UI\n")
    try: s.serve_forever()
    except KeyboardInterrupt: print()
    finally: s.server_close()

if __name__ == "__main__": main()
